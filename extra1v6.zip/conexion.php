<?php
$server = "localhost";
$user = "root";
$password = "";
$dbname = "registros";

$conexion = mysqli_connect($server, $user, $password, $dbname);

if (!$conexion) {
	die("Error: " . mysqli_connect_error());
}
?>